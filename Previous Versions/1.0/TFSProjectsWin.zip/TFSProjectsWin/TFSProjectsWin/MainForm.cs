﻿/*
 ###############################################################################
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################
*/

/*
 * Created by SharpDevelop.
 * User: jeberhar
 * Copyright 2010 Jay Eberhard
 * 
 */
 
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Server;

delegate void writer();

namespace TFSProjectsWin
{
	/// <summary>
	/// The Main Form for TFS Project Audit
	/// </summary>
	public partial class frmMain : Form
	{
		public frmMain()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		
		void BtnOKClick(object sender, EventArgs e)
		{	
			//toolStripStatusLabel1.Text = "Working...";
			//backgroundWorker1.RunWorkerAsync();
			
			richTextBox1.Clear();
			
			string http = "http://";
			string colon = ":";
			string serverName = txtHost.Text;
			string portNumber = txtPort.Text;
			string serverUri = string.Concat(http, serverName, colon, portNumber);
			string projectName = txtProject.Text;
			int count = 0;
			
			try
			{
				// Connect to the server
            	TeamFoundationServer server = new TeamFoundationServer(serverUri);
            	
            	// Get ICommonStructureService (later to be used to list all team projects)
            	ICommonStructureService iss = (ICommonStructureService) server.GetService(typeof(ICommonStructureService));

            	// Get IGroupSecurityService (later to be used to retrieve identity information)
            	IGroupSecurityService2 gss = (IGroupSecurityService2) server.GetService(typeof(IGroupSecurityService2));
            	
            	// List all the TFS Team Projects that exist on a server
           		ProjectInfo[] allTeamProjects = iss.ListProjects();
           		
           		// Iterate thru the team project list
            	if (projectName == "")
            	{
            		foreach (ProjectInfo pi in allTeamProjects)
            		{
             	   		// ProjectInfo gives you the team project's name, status, and URI.
             	   		String teamProjectName = pi.Name;
          	       		ProjectState teamProjectState = pi.Status;
         	       		String teamProjectUri = pi.Uri;
         	       		count = count +1;

         	       		// Print team project info
              	   		richTextBox1.AppendText(string.Format("\nProject Name : {0}", teamProjectName));

                		// Skip this team project if it is not WellFormed.
              	    	if (teamProjectState != ProjectState.WellFormed)
                		{
                    		continue;
                		}
				
                		// For each Team project identify each security Group
                		Identity[] allProjectGroups = gss.ListApplicationGroups(teamProjectUri);

                		// Iterate thru the project group list and get a list of direct members for each project group
                		foreach (Identity projectGroup in allProjectGroups)
                		{
                    		// For each Security Group, I need to identify all the users that belong to that group
                    		Identity pg = gss.ReadIdentity(SearchFactor.Sid, projectGroup.Sid, QueryMembership.Direct);

                    		richTextBox1.AppendText(string.Format("\n\tProject Group Name : {0}", pg.DisplayName));
                    		
                    		// print detailed identity info for each group member
                    		foreach (String groupMemberSid in pg.Members)
                    		{
                    			Identity m = gss.ReadIdentity(SearchFactor.Sid, groupMemberSid, QueryMembership.None);

                        		richTextBox1.AppendText(string.Format("\n\t\tName : {0}\tEmail : {1}", m.DisplayName, m.MailAddress));
                    		}
                		}
            		}
            		//MessageBox.Show(string.Format("\nThere are {0} projects on {1}", count, serverUri));
            		richTextBox1.AppendText(string.Format("\n\nThere are {0} projects on {1}", count, serverUri));
            	} else {
            		ProjectInfo pi = (iss.GetProjectFromName(projectName));
            	
            		string singleProject = pi.Name;
					string singleUri = pi.Uri;
					
					richTextBox1.AppendText(string.Format("Project Name : {0}", singleProject));
					
					Identity[] projectGroups = gss.ListApplicationGroups(singleUri);
					
					foreach (Identity projectGroup in projectGroups)
                	{
                    	// For each Security Group identify all the users that belong to that group
                    	Identity pg = gss.ReadIdentity(SearchFactor.Sid, projectGroup.Sid, QueryMembership.Direct);

                    	richTextBox1.AppendText(string.Format("\n\tProject Group Name : {0}", pg.DisplayName));

                    	// Print detailed identity info for each group member
                    	foreach (String groupMemberSid in pg.Members)
                    	{
                        	Identity m = gss.ReadIdentity(SearchFactor.Sid, groupMemberSid, QueryMembership.None);
                        	
                        	richTextBox1.AppendText(string.Format("\n\t\tName : {0}\tEmail : {1}", m.DisplayName, m.MailAddress));
                    	}
                	}
            	}
			}
			catch
			{
				richTextBox1.AppendText("\nTFSProjects.exe -- Team Foundation Server Project Audit\n\n");
			    richTextBox1.AppendText("Supply a valid TFS name and port number, and optionally a project name on the server.\n");
			    richTextBox1.AppendText("Note: TFSServerPort is 8080 by default, if not contact your sysadmin.\n");
			    richTextBox1.AppendText("\nFUNCTION: lists all users for each project or for only one project and their roles for a TFS installation.");
			    richTextBox1.AppendText("\nIndividual projects may be specified in the third text box.");
			    
			}
		}
				
		void MainFormLoad(object sender, EventArgs e)
		{
			richTextBox1.AppendText("\nTFS Project Audit 1.0 by Jay Eberhard Copyright 2010.\n");
			richTextBox1.AppendText("Press the OK button with zero values applied for brief description .\n");
			richTextBox1.AppendText("Protected by GPL, read COPYING.txt before making changes./n");
		}
	}
}