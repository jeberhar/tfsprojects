﻿/*
 * Created by SharpDevelop.
 * User: jeberhar
 * Date: 2/8/2010
 * Time: 9:29 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace TFSProjectsWin
{
	partial class frmMain
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.required1 = new System.Windows.Forms.Label();
			this.btnOK = new System.Windows.Forms.Button();
			this.lblProject = new System.Windows.Forms.Label();
			this.lblPort = new System.Windows.Forms.Label();
			this.lblHost = new System.Windows.Forms.Label();
			this.txtProject = new System.Windows.Forms.TextBox();
			this.txtPort = new System.Windows.Forms.TextBox();
			this.txtHost = new System.Windows.Forms.TextBox();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.required1);
			this.groupBox1.Controls.Add(this.btnOK);
			this.groupBox1.Controls.Add(this.lblProject);
			this.groupBox1.Controls.Add(this.lblPort);
			this.groupBox1.Controls.Add(this.lblHost);
			this.groupBox1.Controls.Add(this.txtProject);
			this.groupBox1.Controls.Add(this.txtPort);
			this.groupBox1.Controls.Add(this.txtHost);
			this.groupBox1.Location = new System.Drawing.Point(12, 12);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(587, 65);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Server Information";
			// 
			// label1
			// 
			this.label1.ForeColor = System.Drawing.Color.Red;
			this.label1.Location = new System.Drawing.Point(234, 47);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 14);
			this.label1.TabIndex = 8;
			this.label1.Text = "required";
			// 
			// required1
			// 
			this.required1.ForeColor = System.Drawing.Color.Red;
			this.required1.Location = new System.Drawing.Point(66, 47);
			this.required1.Name = "required1";
			this.required1.Size = new System.Drawing.Size(100, 14);
			this.required1.TabIndex = 7;
			this.required1.Text = "required";
			// 
			// btnOK
			// 
			this.btnOK.Location = new System.Drawing.Point(506, 24);
			this.btnOK.Name = "btnOK";
			this.btnOK.Size = new System.Drawing.Size(75, 23);
			this.btnOK.TabIndex = 6;
			this.btnOK.Text = "OK";
			this.btnOK.UseVisualStyleBackColor = true;
			this.btnOK.Click += new System.EventHandler(this.BtnOKClick);
			// 
			// lblProject
			// 
			this.lblProject.Location = new System.Drawing.Point(342, 30);
			this.lblProject.Name = "lblProject";
			this.lblProject.Size = new System.Drawing.Size(43, 16);
			this.lblProject.TabIndex = 5;
			this.lblProject.Text = "Project:";
			// 
			// lblPort
			// 
			this.lblPort.Location = new System.Drawing.Point(175, 29);
			this.lblPort.Name = "lblPort";
			this.lblPort.Size = new System.Drawing.Size(52, 17);
			this.lblPort.TabIndex = 4;
			this.lblPort.Text = "TFS Port:";
			// 
			// lblHost
			// 
			this.lblHost.Location = new System.Drawing.Point(5, 29);
			this.lblHost.Name = "lblHost";
			this.lblHost.Size = new System.Drawing.Size(56, 17);
			this.lblHost.TabIndex = 3;
			this.lblHost.Text = "TFS Host:";
			// 
			// txtProject
			// 
			this.txtProject.Location = new System.Drawing.Point(391, 26);
			this.txtProject.Name = "txtProject";
			this.txtProject.Size = new System.Drawing.Size(100, 20);
			this.txtProject.TabIndex = 2;
			// 
			// txtPort
			// 
			this.txtPort.Location = new System.Drawing.Point(233, 26);
			this.txtPort.Name = "txtPort";
			this.txtPort.Size = new System.Drawing.Size(100, 20);
			this.txtPort.TabIndex = 1;
			// 
			// txtHost
			// 
			this.txtHost.Location = new System.Drawing.Point(67, 26);
			this.txtHost.Name = "txtHost";
			this.txtHost.Size = new System.Drawing.Size(100, 20);
			this.txtHost.TabIndex = 0;
			// 
			// richTextBox1
			// 
			this.richTextBox1.BackColor = System.Drawing.SystemColors.Window;
			this.richTextBox1.Location = new System.Drawing.Point(12, 83);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.ReadOnly = true;
			this.richTextBox1.Size = new System.Drawing.Size(587, 421);
			this.richTextBox1.TabIndex = 1;
			this.richTextBox1.Text = "";
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(613, 521);
			this.Controls.Add(this.richTextBox1);
			this.Controls.Add(this.groupBox1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "frmMain";
			this.Text = "TFS Projects";
			this.Load += new System.EventHandler(this.MainFormLoad);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);
		}
		private System.Windows.Forms.Label required1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.Label lblHost;
		private System.Windows.Forms.TextBox txtProject;
		private System.Windows.Forms.TextBox txtPort;
		private System.Windows.Forms.TextBox txtHost;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Label lblProject;
		private System.Windows.Forms.Label lblPort;
		private System.Windows.Forms.GroupBox groupBox1;
	}
}
