﻿/*
 ###############################################################################
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################
*/

/*
 * Created by SharpDevelop.
 * User: jeberhar
 * Date: 2/8/2010
 * Time: 9:29 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace TFSProjectsWin
{
	partial class frmMain
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboVersion = new System.Windows.Forms.ComboBox();
            this.lblVersion = new System.Windows.Forms.Label();
            this.cboProject = new System.Windows.Forms.ComboBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.cboRoles = new System.Windows.Forms.ComboBox();
            this.lblRoles = new System.Windows.Forms.Label();
            this.required3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.required1 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.lblProject = new System.Windows.Forms.Label();
            this.lblPort = new System.Windows.Forms.Label();
            this.lblHost = new System.Windows.Forms.Label();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.txtHost = new System.Windows.Forms.TextBox();
            this.rtfMain = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblSave = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblSave);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.cboVersion);
            this.groupBox1.Controls.Add(this.lblVersion);
            this.groupBox1.Controls.Add(this.cboProject);
            this.groupBox1.Controls.Add(this.btnConnect);
            this.groupBox1.Controls.Add(this.cboRoles);
            this.groupBox1.Controls.Add(this.lblRoles);
            this.groupBox1.Controls.Add(this.required3);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.required1);
            this.groupBox1.Controls.Add(this.btnOK);
            this.groupBox1.Controls.Add(this.lblProject);
            this.groupBox1.Controls.Add(this.lblPort);
            this.groupBox1.Controls.Add(this.lblHost);
            this.groupBox1.Controls.Add(this.txtPort);
            this.groupBox1.Controls.Add(this.txtHost);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(783, 110);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Server Information";
            // 
            // cboVersion
            // 
            this.cboVersion.FormattingEnabled = true;
            this.cboVersion.Location = new System.Drawing.Point(511, 24);
            this.cboVersion.Name = "cboVersion";
            this.cboVersion.Size = new System.Drawing.Size(130, 21);
            this.cboVersion.TabIndex = 13;
            // 
            // lblVersion
            // 
            this.lblVersion.Location = new System.Drawing.Point(437, 26);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(69, 16);
            this.lblVersion.TabIndex = 12;
            this.lblVersion.Text = "TFS Version:";
            // 
            // cboProject
            // 
            this.cboProject.FormattingEnabled = true;
            this.cboProject.Location = new System.Drawing.Point(301, 60);
            this.cboProject.Name = "cboProject";
            this.cboProject.Size = new System.Drawing.Size(130, 21);
            this.cboProject.TabIndex = 4;
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(647, 21);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(130, 23);
            this.btnConnect.TabIndex = 2;
            this.btnConnect.Text = "Connect to Server";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.BtnConnectClick);
            // 
            // cboRoles
            // 
            this.cboRoles.FormattingEnabled = true;
            this.cboRoles.Location = new System.Drawing.Point(87, 64);
            this.cboRoles.Name = "cboRoles";
            this.cboRoles.Size = new System.Drawing.Size(130, 21);
            this.cboRoles.TabIndex = 3;
            // 
            // lblRoles
            // 
            this.lblRoles.Location = new System.Drawing.Point(6, 67);
            this.lblRoles.Name = "lblRoles";
            this.lblRoles.Size = new System.Drawing.Size(77, 17);
            this.lblRoles.TabIndex = 11;
            this.lblRoles.Text = "Project Role:";
            // 
            // required3
            // 
            this.required3.ForeColor = System.Drawing.Color.Red;
            this.required3.Location = new System.Drawing.Point(87, 88);
            this.required3.Name = "required3";
            this.required3.Size = new System.Drawing.Size(100, 14);
            this.required3.TabIndex = 10;
            this.required3.Text = "required";
            // 
            // label1
            // 
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(302, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 14);
            this.label1.TabIndex = 8;
            this.label1.Text = "required";
            // 
            // required1
            // 
            this.required1.ForeColor = System.Drawing.Color.Red;
            this.required1.Location = new System.Drawing.Point(88, 44);
            this.required1.Name = "required1";
            this.required1.Size = new System.Drawing.Size(100, 14);
            this.required1.TabIndex = 7;
            this.required1.Text = "required";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(647, 60);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(130, 23);
            this.btnOK.TabIndex = 5;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.BtnOKClick);
            // 
            // lblProject
            // 
            this.lblProject.Location = new System.Drawing.Point(252, 66);
            this.lblProject.Name = "lblProject";
            this.lblProject.Size = new System.Drawing.Size(43, 16);
            this.lblProject.TabIndex = 5;
            this.lblProject.Text = "Project:";
            // 
            // lblPort
            // 
            this.lblPort.Location = new System.Drawing.Point(243, 26);
            this.lblPort.Name = "lblPort";
            this.lblPort.Size = new System.Drawing.Size(52, 17);
            this.lblPort.TabIndex = 3;
            this.lblPort.Text = "TFS Port:";
            // 
            // lblHost
            // 
            this.lblHost.Location = new System.Drawing.Point(27, 26);
            this.lblHost.Name = "lblHost";
            this.lblHost.Size = new System.Drawing.Size(56, 17);
            this.lblHost.TabIndex = 3;
            this.lblHost.Text = "TFS Host:";
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(301, 23);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(130, 20);
            this.txtPort.TabIndex = 1;
            // 
            // txtHost
            // 
            this.txtHost.Location = new System.Drawing.Point(89, 23);
            this.txtHost.Name = "txtHost";
            this.txtHost.Size = new System.Drawing.Size(130, 20);
            this.txtHost.TabIndex = 0;
            // 
            // rtfMain
            // 
            this.rtfMain.BackColor = System.Drawing.SystemColors.Window;
            this.rtfMain.Location = new System.Drawing.Point(12, 128);
            this.rtfMain.Name = "rtfMain";
            this.rtfMain.ReadOnly = true;
            this.rtfMain.Size = new System.Drawing.Size(783, 454);
            this.rtfMain.TabIndex = 5;
            this.rtfMain.Text = "";
            // 
            // label3
            // 
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(508, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 14);
            this.label3.TabIndex = 14;
            this.label3.Text = "required";
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(511, 61);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(130, 23);
            this.btnSave.TabIndex = 15;
            this.btnSave.Text = "Save Results...";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblSave
            // 
            this.lblSave.Enabled = false;
            this.lblSave.Location = new System.Drawing.Point(467, 67);
            this.lblSave.Name = "lblSave";
            this.lblSave.Size = new System.Drawing.Size(38, 19);
            this.lblSave.TabIndex = 16;
            this.lblSave.Text = "Save :";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(807, 596);
            this.Controls.Add(this.rtfMain);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Text = "TFS Projects";
            this.Load += new System.EventHandler(this.MainFormLoad);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

		}
		private System.Windows.Forms.ComboBox cboProject;
		private System.Windows.Forms.Button btnConnect;
		private System.Windows.Forms.RichTextBox rtfMain;
		private System.Windows.Forms.ComboBox cboRoles;
		private System.Windows.Forms.Label required3;
		private System.Windows.Forms.Label lblRoles;
		private System.Windows.Forms.Label required1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblHost;
		private System.Windows.Forms.TextBox txtPort;
		private System.Windows.Forms.TextBox txtHost;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Label lblProject;
		private System.Windows.Forms.Label lblPort;
		private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cboVersion;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label lblSave;
		
		
	}
}
