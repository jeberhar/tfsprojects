﻿/*
 ###############################################################################
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################
*/

/*
 * User: jeberhar
 * Copyright 2010 Jay Eberhard
 * 
 */
 
using System;
using System.Collections.Generic;
using System.Collections;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Xml;
using System.Windows.Forms;
using System.Linq;
using System.Text;
using System.Threading;

using Microsoft.TeamFoundation.Build.Client;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Proxy;
using Microsoft.TeamFoundation.Server;
using Microsoft.TeamFoundation.WorkItemTracking.Client;
using Microsoft.TeamFoundation.Framework.Client;
using Microsoft.TeamFoundation.Framework.Common;

namespace TFSProjectsWin
{
	/// <summary>
	/// The Main Form for TFS Project Audit
	/// </summary>
	public partial class frmMain : Form
	{
        string http = "http://";
        string colon = ":";
        string serverName = "";
        string portNumber = "";
        string serverURI = "";
        string serverURInospace = "";
        string tfsdir = "/tfs/";
        string tfsCollection = "";
        string tfsVersion = "";

        TeamFoundationServer TFSserver = new TeamFoundationServer("http://localhost:8080");
        ICommonStructureService iss;
        IGroupSecurityService2 gss;
        ProjectInfo[] allTeamProjects;
        Identity[] allProjectGroups;
        
        string threadExceptionMessage = "";        

		public frmMain()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//		

			InitializeComponent();

			//
			// 
			//
		}
		
		void BtnConnectClick(object sender, System.EventArgs e)
		{	
			Cursor.Current = Cursors.WaitCursor;
			rtfMain.Clear();
            serverURInospace = "";

            serverName = txtHost.Text;
            portNumber = txtPort.Text;
            tfsCollection = txtCollection.Text;
            if (chkTFS2010.Checked == true)
            {
                serverURI = string.Concat(http, serverName, colon, portNumber, tfsdir, tfsCollection);                
            }
            else
            {
                serverURI = string.Concat(http, serverName, colon, portNumber);
            }

            //hide spaces in the server URI by replacing them with underscores. For display purposes only!
            serverURInospace = serverURI;
            if (serverURI.Contains(" "))
            {
                serverURInospace = serverURI.Replace(" ", "_");
            }

            try
			{
				//revert to help text if server name has no value
				if (serverName == "")
				{
					throw new Exception();
				}
				
				//revert to help text if server port has no value
				if (portNumber == "")
				{
					throw new Exception();
				}

                //chkTFS2010 shouldn't be checked if tfsCollection has a value
                if ((chkTFS2010.Checked == true) && (tfsCollection == ""))
                {
                    throw new Exception();
                }

                //chkTFS2010 should be checked if tfsCollection has a value
                if ((chkTFS2010.Checked == false) && (tfsCollection != ""))
                {
                    throw new Exception();
                }
				
				// Connect to the server
				
				//Sorry folks, threading just doesn't work well with the TFS API.
                //Weird connection errors occur when it is implemented so it is not recommended.
                //Also, speed improvements are negligibe, if present at all.
                //Anyone out there with threading expertise greater than mine is welcome to comment on improvements!

                TeamFoundationServer TFSserver = new TeamFoundationServer(serverURI);
                
                //Get TFS version from the server and apply meaningful name values
                IBuildServer buildServer = (IBuildServer)TFSserver.GetService(typeof(IBuildServer));
                string tfsVer = buildServer.BuildServerVersion.ToString();
                if (tfsVer == "V3")
                {
                    tfsVersion = "Microsoft Team Foundation Server 2010";
                }
                if (tfsVer == "V2")
                {
                    tfsVersion = "Microsoft Team Foundation Server 2008";
                }

                //Thread goTFS = new Thread(new ThreadStart(connectTFS));
				//goTFS.Start();
            	
            	// Get ICommonStructureService (later to be used to list all team projects)
            	iss = (ICommonStructureService) TFSserver.GetService(typeof(ICommonStructureService));

                // TFS 2010 - get project collections
                RegisteredProjectCollection[] collections = RegisteredTfsConnections.GetProjectCollections();
                
                //TFS 2010 - get list of projects
                //WorkItemStore newProjects = new WorkItemStore(tfs);
                //allNewTeamProjects = newProjects.Projects;
                

            	//Thread goISS = new Thread(new ThreadStart(connectISS));
            	//goISS.Start();

            	// Get IGroupSecurityService (later to be used to retrieve identity information)
            	gss = (IGroupSecurityService2) TFSserver.GetService(typeof(IGroupSecurityService2));
            	//Thread goGSS = new Thread(new ThreadStart(connectGSS));
            	//goGSS.Start();

                //goTFS.Join();
                //goISS.Join();
                //goGSS.Join();

            	// List all the TFS Team Projects that exist on a server
           		allTeamProjects = iss.ListProjects();

           		ArrayList myTeamProjects = new ArrayList();
                ArrayList myTeamRoles = new ArrayList();
                string collectionName = "";
                string collectionDelimiter = "\\";

           		myTeamProjects.Add(" All");
           		myTeamRoles.Add(" All");

                foreach (ProjectInfo TFSProjectInfo in allTeamProjects)
           		{
           			String teamProjectURI = TFSProjectInfo.Uri;
           			
           			// For each Team project identify each security Group
                	allProjectGroups = gss.ListApplicationGroups(teamProjectURI);
                	
                	foreach (Identity projectGroup in allProjectGroups)
                	{
                		if (myTeamRoles.Contains(projectGroup.DisplayName.ToString()))
                		{
                			continue;
                		}
                		else
                		{
                			myTeamRoles.Add(projectGroup.DisplayName.ToString());
                		}
                	}
                
           			myTeamProjects.Add(TFSProjectInfo.Name.ToString());
           		}

                myTeamProjects.Sort();
                myTeamRoles.Sort();
           		
           		cboProject.DataSource = myTeamProjects;
           		cboRoles.DataSource = myTeamRoles;
           		
           		lblRoles.Enabled = true;
				cboRoles.Enabled = true;
				required3.Enabled = true;
				lblProject.Enabled = true;
				cboProject.Enabled = true;
                lblSave.Enabled = true;
                btnSave.Enabled = true;
				btnOK.Enabled = true;

                rtfMain.AppendText(string.Format("\nConnection successful to {0} please select the roles and project then click OK.\n\n", serverURInospace));
                if (chkTFS2010.Checked == true)
                {
                    rtfMain.AppendText(string.Format("\nThe following collections were reported by {0}:\n", serverName));
                    foreach (RegisteredProjectCollection TFSCollection in collections)
                    {
                        collectionName = TFSCollection.Name.ToString();
                        if (collectionName.Contains(collectionDelimiter) == true)
                        {
                            rtfMain.AppendText(string.Format("\n Collection: {0}", collectionName));
                        }
                    }
                }
                rtfMain.AppendText(string.Format("\n\nTFS Version Confirmation: {0} on {1}.\n\n", tfsVersion, serverName));

				Cursor.Current = Cursors.Default;
			}
			catch (Exception ex)
			{		
				lblRoles.Enabled = false;
				cboRoles.Enabled = false;
				required3.Enabled = false;
				lblProject.Enabled = false;
				cboProject.Enabled = false;
                lblSave.Enabled = false;
                btnSave.Enabled = false;
				btnOK.Enabled = false;

                if ((serverName == "") || (portNumber == ""))
                {
                    string error = "\nERROR: Server Name and Port Number can't be null!\n";
                    rtfMain.AppendText(error);
                    rtfMain.SelectionStart = 0;
                    rtfMain.SelectionLength = error.Length;
                    rtfMain.SelectionColor = Color.Red;
                    rtfMain.SelectionLength = 0;
                    rtfMain.SelectionColor = Color.Black;
                    rtfMain.AppendText("\nPlease check your server name and/or port number values and try again.\n");
                }
                else if ((chkTFS2010.Checked == true) && (tfsCollection == ""))
                {
                    string error = "\nERROR: For TFS 2010 a collection name MUST be specified!\n";
                    rtfMain.AppendText(error);
                    rtfMain.SelectionStart = 0;
                    rtfMain.SelectionLength = error.Length;
                    rtfMain.SelectionColor = Color.Red;
                    rtfMain.SelectionLength = 0;
                    rtfMain.SelectionColor = Color.Black;
                    rtfMain.AppendText("\nPlease check your collection name and version input values and try again.\n");
                }
                else if ((chkTFS2010.Checked == false) && (tfsCollection.Length > 0))
                {
                    string error = "\nERROR: TFS 2010 collection specified for non-2010 version!\n";
                    rtfMain.AppendText(error);
                    rtfMain.SelectionStart = 0;
                    rtfMain.SelectionLength = error.Length;
                    rtfMain.SelectionColor = Color.Red;
                    rtfMain.SelectionLength = 0;
                    rtfMain.SelectionColor = Color.Black;
                    rtfMain.AppendText("\nPlease check your collection name and/or version input values and try again.\n");
                }
                else
                {
                    string error = "\nERROR: " + ex.Message + "\n";
                    rtfMain.AppendText(error);
                    rtfMain.SelectionStart = 0;
                    rtfMain.SelectionLength = error.Length;
                    rtfMain.SelectionColor = Color.Red;
                    rtfMain.SelectionLength = 0;
                    rtfMain.SelectionColor = Color.Black;
                    rtfMain.AppendText("\nPlease check your input values and try again.\n");
                }
                    
                /* Unused threading error catch
                if (threadExceptionMessage != " ")
                {
                    rtfMain.AppendText("\nERROR 04: " + threadExceptionMessage + "\n\n");
                }
                */
			}
		}

		void BtnOKClick(object sender, EventArgs e)
		{				
			Cursor.Current = Cursors.WaitCursor;
			rtfMain.Clear();
			
			string projectName = cboProject.Text.ToString();
			int projectCount = 0;
			int idCount = 0;
			
			try
			{	
           		//string variable for the value in the Project Roles combo box
			    string providedGroup = cboRoles.Text.ToString();

          		// Iterate thru the team project list
            	if (projectName == " All")
            	{
                    foreach (ProjectInfo TFSProjectInfo in allTeamProjects)
            		{                      
                        // ProjectInfo gives you the team project's name, status, and URI.
             	   		string teamProjectName = TFSProjectInfo.Name;
          	       		ProjectState teamProjectState = TFSProjectInfo.Status;
         	       		string teamProjectUri = TFSProjectInfo.Uri;

                        //string teamProjectURI = TFSProjectInfo.Uri;
                        
                        // For each Team project identify each security Group
                        allProjectGroups = gss.ListApplicationGroups(teamProjectUri);

                        // Skip this team project if it is not WellFormed.
                        if (teamProjectName == " All")
                        {
                            continue;
                        }
                        
                        projectCount = projectCount + 1;

         	       		// Print team project info
              	   		rtfMain.AppendText(string.Format("\nProject Name: {0}", teamProjectName));

                		// Skip this team project if it is not WellFormed.
              	    	if (teamProjectState != ProjectState.WellFormed)
                		{
                            //TODO add warning here
                    		continue;
                		}

                		// Iterate thru the project group list and get a list of direct members for each project group
                		foreach (Identity projectGroup in allProjectGroups)
                		{                           
                			string projGroup = projectGroup.DisplayName.ToString();
                			if ((projGroup.Contains(providedGroup) == true)||providedGroup.Equals(" All"))
                			{
                				// For each Security Group, identify all the users that belong to that group
                    			Identity projectGroupIdentity = gss.ReadIdentity(SearchFactor.Sid, projectGroup.Sid, QueryMembership.Direct);

                    			rtfMain.AppendText(string.Format("\n\tProject Group Name: {0}", projectGroupIdentity.DisplayName));
                    		
                    			// print detailed identity info for each group member
                    			foreach (String groupMemberSID in projectGroupIdentity.Members)
                    			{
                    				idCount = idCount + 1;
                    				Identity tfsID = gss.ReadIdentity(SearchFactor.Sid, groupMemberSID, QueryMembership.None);
                        			rtfMain.AppendText(string.Format("\n\t\tName : {0}\t\t\tEmail : {1}", tfsID.DisplayName, tfsID.MailAddress));
                    			}
                    			rtfMain.AppendText(string.Format("\n\t\tThere are {0} users in the {1} group for {2}.", idCount, projectGroupIdentity.DisplayName, teamProjectName));
                    			idCount = 0;
                			}
                            
                		}
            		}
            		rtfMain.AppendText(string.Format("\n\nThere are {0} projects on {1}", projectCount, serverURInospace));
            		Cursor.Current = Cursors.Default;
            	} else {
            		Cursor.Current = Cursors.WaitCursor;
            		ProjectInfo TFSProjectInfo = (iss.GetProjectFromName(projectName));
            	
            		string singleProject = TFSProjectInfo.Name;
					string singleURI = TFSProjectInfo.Uri;
					int singleIdCount = 0;
					
					rtfMain.AppendText(string.Format("Project Name : {0}", singleProject));
					
					Identity[] projectGroups = gss.ListApplicationGroups(singleURI);
					
					foreach (Identity projectGroup in projectGroups)
                	{
                    	string projGroup = projectGroup.DisplayName.ToString();
                    	
						if ((projGroup.Contains(providedGroup) == true)||providedGroup.Contains(" All"))
                		{
                    		// For each Security Group identify all the users that belong to that group
                    		Identity projectGroupIdentity = gss.ReadIdentity(SearchFactor.Sid, projectGroup.Sid, QueryMembership.Direct);

                    		rtfMain.AppendText(string.Format("\n\tProject Group Name : {0}", projectGroupIdentity.DisplayName));

                    		// Print detailed identity info for each group member
                    		foreach (String groupMemberSid in projectGroupIdentity.Members)
                    		{
                        		singleIdCount = singleIdCount + 1;
                    			Identity tfsID = gss.ReadIdentity(SearchFactor.Sid, groupMemberSid, QueryMembership.None);
                        		rtfMain.AppendText(string.Format("\n\t\tName : {0}\t\t\tEmail : {1}", tfsID.DisplayName, tfsID.MailAddress));
                    		}
						rtfMain.AppendText(string.Format("\n\t\tThere are {0} users in the {1} group for {2}.", singleIdCount, projectGroupIdentity.DisplayName, singleProject));
						singleIdCount = 0;
						}
                	}
					Cursor.Current = Cursors.Default;
            	}
			}
			catch (Exception ex)
			{
                string error = "\nERROR: " + ex.Message + "\n";
                rtfMain.AppendText(error);
                rtfMain.SelectionStart = 0;
                rtfMain.SelectionLength = error.Length;
                rtfMain.SelectionColor = Color.Red;
                rtfMain.SelectionLength = 0;
                rtfMain.SelectionColor = Color.Black;
                rtfMain.AppendText("\nPlease check the status of your TFS instance and try again.\n");
                //rtfMain.AppendText("ERROR: " + threadExceptionMessage + "\n\n");
			}
		}
				
		void MainFormLoad(object sender, EventArgs e)
		{
			lblRoles.Enabled = false;
			cboRoles.Enabled = false;
			required3.Enabled = false;
			lblProject.Enabled = false;
			cboProject.Enabled = false;
			btnOK.Enabled = false;

			rtfMain.AppendText("\nTFS Project Audit 1.6 by Jay Eberhard Copyright 2010.\n\n");
			rtfMain.AppendText("Press the Help button at any time for information for the description and usage info.\n\n");
			rtfMain.AppendText("Protected by GPL, read COPYING.txt before making any changes.\n\n");
            rtfMain.AppendText("\n\nTFS 2010 Users: Please install the TFS 2010 Forward Compatibility Pack!\n\n");
            rtfMain.AppendText("http://www.microsoft.com/downloads/details.aspx?FamilyID=CF13EA45-D17B-4EDC-8E6C-6C5B208EC54D&displaylang=en");
            rtfMain.AppendText("\n\nTFS 2005 Users MUST use version 1.0 of TFS Projects, which is available on http://tfsprojects.codeplex.com");
		}
		#region unused TFS connection methods for threading
		void connectTFS()
		{
			try
			{
				TFSserver = new TeamFoundationServer(serverURI);
			}
			catch (Exception ex)
			{
				threadExceptionMessage = ex.Message.ToString();
			}
		}
		void connectISS()
		{
			try
			{	
				iss = (ICommonStructureService) TFSserver.GetService(typeof(ICommonStructureService));
				
			}
			catch (Exception ex)
			{
                threadExceptionMessage = ex.Message.ToString();
			}
		}
		void connectGSS()
		{
			try
			{
				gss = (IGroupSecurityService2) TFSserver.GetService(typeof(IGroupSecurityService2));
				
			}
			catch (Exception ex)
			{
                threadExceptionMessage = ex.Message.ToString();
			}
			
		}
		#endregion	
		
		void helpText()
		{
				serverName = " ";
        		portNumber = " ";
			
				rtfMain.AppendText("\nTFS Projects -- Team Foundation Server Project Audit Tool\n\n");
			    rtfMain.AppendText("Supply a valid TFS name, port number and TFS Version and collection name (if applicable), then click Connect to Server.\n\nUpon successful connection select project role or all roles for all projects or individual project and click OK.  " + 
				                   "\nOptionally a specific project or role on the server may be selected.  Results can also be saved by clicking the Save Results... button. \n\n");
                rtfMain.AppendText("Project related configuration items will only become available upon successful connection to the TFS instance provided.\n\n");
                rtfMain.AppendText("When specifying a collection for TFS 2010 you only need supply the actual collection name, no backslashes, and server name \n");
                rtfMain.AppendText("only needs to be specified in the TFS Host field and should not be included in the collection name.\n\n");
                rtfMain.AppendText("Note: TFS port is 8080 by default, if this value gives an error contact your sysadmin for your port number.\n");
			    rtfMain.AppendText("\nFUNCTION: lists all users for each project or for only one project and their roles for a TFS installation.");
			    rtfMain.AppendText("\nIndividual projects may be selected from the provided combo box once the connection is established.");
                rtfMain.AppendText("\n\nTFS 2010 Users: Please install the TFS 2010 Forward Compatibility Pack!\n\n");
                rtfMain.AppendText("http://www.microsoft.com/downloads/details.aspx?FamilyID=CF13EA45-D17B-4EDC-8E6C-6C5B208EC54D&displaylang=en");
                rtfMain.AppendText("\n\nTFS 2005 Users MUST use version 1.0 of TFS Projects, which is available on http://tfsprojects.codeplex.com");
                rtfMain.AppendText("\n\nTFS Project Audit 1.6 by Jay Eberhard Copyright 2010.\n\n");

		}

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.DefaultExt = "*.rtf";
            sfd.Filter = "RTF Files|*.rtf";


            if ((sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK) && sfd.FileName.Length > 0)
            {
                rtfMain.SaveFile(sfd.FileName);
            }
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            rtfMain.Clear();
            helpText();
        }

	}
}