﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
//using System.Threading; //unused

namespace TFSProjectsWin
{
    class DisplayText
    {
        #region variables

        private frmMain mainForm; //variable to receive controls from MainForm
        private string printText = ""; //local text holder variable

        #endregion

        //constructor
        public DisplayText(frmMain form1)
        {
            mainForm = form1;
        }

        #region display initialization text

        public void initText()
        {
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.Clear(); }));

            printText = "\nTFS Project Audit 2.0 by Jay Eberhard Copyright 2014.\n\n";
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionLength = printText.Length; }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial",mainForm.rtfMain.Font.Size, FontStyle.Bold); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText(printText); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial", mainForm.rtfMain.Font.Size, FontStyle.Regular); }));
            printText = "";

            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("Press the Help button at any time for information for the description and usage info.\n\n"); }));

            printText = "Protected by GPL, read COPYING.txt before making any changes.\n\n";
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionLength = printText.Length; }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial", mainForm.rtfMain.Font.Size, FontStyle.Underline); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText(printText); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial", mainForm.rtfMain.Font.Size, FontStyle.Regular); }));
            printText = "";

            printText = "The TFS 2010 Forward Compatibility Pack is no longer required for TFS Projects.\n\n";
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionLength = printText.Length; }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionColor = Color.Red; }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText(printText); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionColor = Color.Black; }));
            printText = "";

            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("TFS 2005 Users MUST use version 1.0 of TFS Projects, which is available on http://tfsprojects.codeplex.com"); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("\n\tFor email list generation, TFS 2005 users must use TFS Users, which is available at http://tfsusers.codeplex.com"); }));
        }

        #endregion

        #region display user guide text

        public void helpText()
        {
            float zoom = mainForm.rtfMain.ZoomFactor;
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.Clear(); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.ZoomFactor = zoom; }));

            printText = "TFS Projects -- Team Foundation Server Project Audit Tool\n\n";
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionLength = printText.Length; }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial", mainForm.rtfMain.Font.Size, FontStyle.Bold); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText(printText); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial", mainForm.rtfMain.Font.Size, FontStyle.Regular); }));
            printText = "";

            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("FUNCTION: lists all users for each project for all collections or a specified collection or for only one project within a collection and their roles for a TFS installation."); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("Individual projects may be selected from the provided combo box once the connection is established."); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("\n\nThe TFS 2010 Forward Compatibility Pack is no longer required for TFS Projects.\n\n"); }));

            printText = "USAGE: Supply a valid TFS name, port number and TFS Version and collection name (if applicable), then click Connect.\nUpon successful connection, select project role or all roles for all projects or individual project and click OK.\n";            
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionLength = printText.Length; }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial", mainForm.rtfMain.Font.Size, FontStyle.Underline); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText(printText); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial", mainForm.rtfMain.Font.Size, FontStyle.Regular); }));
            printText = "";

            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("\nOptionally, a specific project or role on the server may be selected.  Results can also be saved by clicking the Save... button. \n\n"); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("To generate a list of email addresses rather than verbose project information based on the specified criteria, check the Email Address List check box.\n\n"); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("Project related user interface items will only become available upon successful connection to the TFS instance provided.\n\n"); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("When specifying a collection for TFS 2010/2012, you only need supply the actual collection name. A server name or any backslashes should not be included in the collection name.\n\n"); }));

            printText = "To gather data from all collections on a TFS 2010/2012 server specify \"all-collections\" without quotes as the collection name in the Collection field.\n\n";
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionLength = printText.Length; }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionColor = Color.Red; }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText(printText); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionColor = Color.Black; }));
            printText = "";

            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("If no collection names are known use all-collections and a list of collections on the server will be provided then you can simply reconnect to the one you need.\n\n"); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("TFS port is 8080 by default, if this value gives an error contact your TFS admin for your port number."); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("\n\nTFS 2005 Users MUST use version 1.0 of TFS Projects, which is available at http://tfsprojects.codeplex.com"); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText("\n\tFor email list generation, TFS 2005 users must use TFS Users, which is available at http://tfsusers.codeplex.com"); }));
            
            printText = "\n\nTFS Project Audit 2.0 by Jay Eberhard Copyright 2014.\n\n";
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionLength = printText.Length; }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial", mainForm.rtfMain.Font.Size, FontStyle.Bold); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.AppendText(printText); }));
            mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.SelectionFont = new Font("Arial", mainForm.rtfMain.Font.Size, FontStyle.Regular); }));
            printText = "";
        }

        #endregion

        #region display legal licence information

        public void copyingText()
        {
            try
            {
                mainForm.rtfMain.Invoke(new MethodInvoker(delegate { mainForm.rtfMain.Clear(); }));
                
                //load all the legal info from the COPYING.rtf file, in the app dir path
                using (StreamReader sr = new StreamReader("COPYING.rtf"))
                {
                    mainForm.rtfMain.Invoke(new MethodInvoker
                        (delegate { mainForm.rtfMain.LoadFile("COPYING.rtf"); })
                    );
                }
            }
            catch (Exception e)
            {
                
                //TODO: Let the user know what went wrong when it can't find the file
               
            }
        }

        #endregion
    }
}
