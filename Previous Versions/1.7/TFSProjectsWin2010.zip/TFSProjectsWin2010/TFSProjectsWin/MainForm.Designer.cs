﻿/*
 ###############################################################################
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################
*/

/*
 * Created by SharpDevelop.
 * User: jeberhar
 * Date: 2/8/2010
 * Time: 9:29 AM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace TFSProjectsWin
{
	partial class frmMain
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chkEmail = new System.Windows.Forms.CheckBox();
            this.btnHelp = new System.Windows.Forms.Button();
            this.chkTFS2010 = new System.Windows.Forms.CheckBox();
            this.required4 = new System.Windows.Forms.Label();
            this.lblCollection = new System.Windows.Forms.Label();
            this.txtCollection = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.cboProject = new System.Windows.Forms.ComboBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.cboRoles = new System.Windows.Forms.ComboBox();
            this.lblRoles = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.required1 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.lblProject = new System.Windows.Forms.Label();
            this.lblPort = new System.Windows.Forms.Label();
            this.lblHost = new System.Windows.Forms.Label();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.txtHost = new System.Windows.Forms.TextBox();
            this.rtfMain = new System.Windows.Forms.RichTextBox();
            this.contextMenuMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStripMain = new System.Windows.Forms.StatusStrip();
            this.toolStripServerLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripServer = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripPortLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripPort = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripCollectionLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripCollection = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripVersionLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripVersion = new System.Windows.Forms.ToolStripStatusLabel();
            this.groupBox1.SuspendLayout();
            this.contextMenuMain.SuspendLayout();
            this.statusStripMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkEmail);
            this.groupBox1.Controls.Add(this.btnHelp);
            this.groupBox1.Controls.Add(this.chkTFS2010);
            this.groupBox1.Controls.Add(this.required4);
            this.groupBox1.Controls.Add(this.lblCollection);
            this.groupBox1.Controls.Add(this.txtCollection);
            this.groupBox1.Controls.Add(this.btnSave);
            this.groupBox1.Controls.Add(this.cboProject);
            this.groupBox1.Controls.Add(this.btnConnect);
            this.groupBox1.Controls.Add(this.cboRoles);
            this.groupBox1.Controls.Add(this.lblRoles);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.required1);
            this.groupBox1.Controls.Add(this.btnOK);
            this.groupBox1.Controls.Add(this.lblProject);
            this.groupBox1.Controls.Add(this.lblPort);
            this.groupBox1.Controls.Add(this.lblHost);
            this.groupBox1.Controls.Add(this.txtPort);
            this.groupBox1.Controls.Add(this.txtHost);
            this.groupBox1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(12, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(892, 118);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Server and Project Information";
            // 
            // chkEmail
            // 
            this.chkEmail.AutoSize = true;
            this.chkEmail.Enabled = false;
            this.chkEmail.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEmail.Location = new System.Drawing.Point(436, 72);
            this.chkEmail.Name = "chkEmail";
            this.chkEmail.Size = new System.Drawing.Size(115, 18);
            this.chkEmail.TabIndex = 7;
            this.chkEmail.Text = "Email Address List";
            this.chkEmail.UseVisualStyleBackColor = true;
            // 
            // btnHelp
            // 
            this.btnHelp.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHelp.Location = new System.Drawing.Point(673, 69);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(70, 25);
            this.btnHelp.TabIndex = 10;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // chkTFS2010
            // 
            this.chkTFS2010.AutoSize = true;
            this.chkTFS2010.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkTFS2010.Location = new System.Drawing.Point(437, 28);
            this.chkTFS2010.Name = "chkTFS2010";
            this.chkTFS2010.Size = new System.Drawing.Size(72, 18);
            this.chkTFS2010.TabIndex = 2;
            this.chkTFS2010.Text = "TFS 2010";
            this.chkTFS2010.UseVisualStyleBackColor = true;
            // 
            // required4
            // 
            this.required4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.required4.ForeColor = System.Drawing.Color.Red;
            this.required4.Location = new System.Drawing.Point(598, 48);
            this.required4.Name = "required4";
            this.required4.Size = new System.Drawing.Size(135, 17);
            this.required4.TabIndex = 19;
            this.required4.Text = "required for TFS 2010";
            // 
            // lblCollection
            // 
            this.lblCollection.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCollection.Location = new System.Drawing.Point(535, 29);
            this.lblCollection.Name = "lblCollection";
            this.lblCollection.Size = new System.Drawing.Size(59, 19);
            this.lblCollection.TabIndex = 18;
            this.lblCollection.Text = "Collection:";
            // 
            // txtCollection
            // 
            this.txtCollection.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCollection.Location = new System.Drawing.Point(595, 26);
            this.txtCollection.Name = "txtCollection";
            this.txtCollection.Size = new System.Drawing.Size(148, 20);
            this.txtCollection.TabIndex = 3;
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(595, 69);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(70, 25);
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save...";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cboProject
            // 
            this.cboProject.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboProject.FormattingEnabled = true;
            this.cboProject.Location = new System.Drawing.Point(296, 69);
            this.cboProject.Name = "cboProject";
            this.cboProject.Size = new System.Drawing.Size(130, 22);
            this.cboProject.TabIndex = 6;
            // 
            // btnConnect
            // 
            this.btnConnect.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.Location = new System.Drawing.Point(757, 25);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(130, 25);
            this.btnConnect.TabIndex = 4;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.BtnConnectClick);
            // 
            // cboRoles
            // 
            this.cboRoles.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboRoles.FormattingEnabled = true;
            this.cboRoles.Location = new System.Drawing.Point(86, 69);
            this.cboRoles.Name = "cboRoles";
            this.cboRoles.Size = new System.Drawing.Size(130, 22);
            this.cboRoles.TabIndex = 5;
            // 
            // lblRoles
            // 
            this.lblRoles.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoles.Location = new System.Drawing.Point(15, 72);
            this.lblRoles.Name = "lblRoles";
            this.lblRoles.Size = new System.Drawing.Size(72, 18);
            this.lblRoles.TabIndex = 11;
            this.lblRoles.Text = "Project Role:";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(299, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "required";
            // 
            // required1
            // 
            this.required1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.required1.ForeColor = System.Drawing.Color.Red;
            this.required1.Location = new System.Drawing.Point(92, 48);
            this.required1.Name = "required1";
            this.required1.Size = new System.Drawing.Size(100, 15);
            this.required1.TabIndex = 7;
            this.required1.Text = "required";
            // 
            // btnOK
            // 
            this.btnOK.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOK.Location = new System.Drawing.Point(757, 69);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(130, 25);
            this.btnOK.TabIndex = 8;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.BtnOKClick);
            // 
            // lblProject
            // 
            this.lblProject.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProject.Location = new System.Drawing.Point(247, 75);
            this.lblProject.Name = "lblProject";
            this.lblProject.Size = new System.Drawing.Size(43, 17);
            this.lblProject.TabIndex = 5;
            this.lblProject.Text = "Project:";
            // 
            // lblPort
            // 
            this.lblPort.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPort.Location = new System.Drawing.Point(238, 28);
            this.lblPort.Name = "lblPort";
            this.lblPort.Size = new System.Drawing.Size(52, 18);
            this.lblPort.TabIndex = 3;
            this.lblPort.Text = "TFS Port:";
            // 
            // lblHost
            // 
            this.lblHost.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHost.Location = new System.Drawing.Point(22, 28);
            this.lblHost.Name = "lblHost";
            this.lblHost.Size = new System.Drawing.Size(62, 18);
            this.lblHost.TabIndex = 3;
            this.lblHost.Text = "TFS Host:";
            // 
            // txtPort
            // 
            this.txtPort.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPort.Location = new System.Drawing.Point(294, 25);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(130, 20);
            this.txtPort.TabIndex = 1;
            // 
            // txtHost
            // 
            this.txtHost.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHost.Location = new System.Drawing.Point(86, 25);
            this.txtHost.Name = "txtHost";
            this.txtHost.Size = new System.Drawing.Size(130, 20);
            this.txtHost.TabIndex = 0;
            // 
            // rtfMain
            // 
            this.rtfMain.BackColor = System.Drawing.SystemColors.Window;
            this.rtfMain.ContextMenuStrip = this.contextMenuMain;
            this.rtfMain.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtfMain.Location = new System.Drawing.Point(12, 138);
            this.rtfMain.Name = "rtfMain";
            this.rtfMain.ReadOnly = true;
            this.rtfMain.Size = new System.Drawing.Size(892, 479);
            this.rtfMain.TabIndex = 5;
            this.rtfMain.Text = "";
            // 
            // contextMenuMain
            // 
            this.contextMenuMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.contextMenuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem,
            this.toolStripSeparator1,
            this.selectAllToolStripMenuItem});
            this.contextMenuMain.Name = "contextMenuStrip1";
            this.contextMenuMain.ShowImageMargin = false;
            this.contextMenuMain.Size = new System.Drawing.Size(143, 54);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(139, 6);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.selectAllToolStripMenuItem.Text = "Select All";
            this.selectAllToolStripMenuItem.Click += new System.EventHandler(this.selectAllToolStripMenuItem_Click);
            // 
            // statusStripMain
            // 
            this.statusStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripServerLabel,
            this.toolStripServer,
            this.toolStripPortLabel,
            this.toolStripPort,
            this.toolStripCollectionLabel,
            this.toolStripCollection,
            this.toolStripVersionLabel,
            this.toolStripVersion});
            this.statusStripMain.Location = new System.Drawing.Point(0, 620);
            this.statusStripMain.Name = "statusStripMain";
            this.statusStripMain.Size = new System.Drawing.Size(916, 22);
            this.statusStripMain.SizingGrip = false;
            this.statusStripMain.TabIndex = 99;
            this.statusStripMain.Text = "statusStripMain";
            // 
            // toolStripServerLabel
            // 
            this.toolStripServerLabel.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripServerLabel.Name = "toolStripServerLabel";
            this.toolStripServerLabel.Size = new System.Drawing.Size(43, 17);
            this.toolStripServerLabel.Text = "Server:";
            // 
            // toolStripServer
            // 
            this.toolStripServer.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripServer.Name = "toolStripServer";
            this.toolStripServer.Size = new System.Drawing.Size(78, 17);
            this.toolStripServer.Text = "Not Connected";
            // 
            // toolStripPortLabel
            // 
            this.toolStripPortLabel.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripPortLabel.Name = "toolStripPortLabel";
            this.toolStripPortLabel.Size = new System.Drawing.Size(29, 17);
            this.toolStripPortLabel.Text = "Port:";
            // 
            // toolStripPort
            // 
            this.toolStripPort.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripPort.Name = "toolStripPort";
            this.toolStripPort.Size = new System.Drawing.Size(78, 17);
            this.toolStripPort.Text = "Not Connected";
            // 
            // toolStripCollectionLabel
            // 
            this.toolStripCollectionLabel.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripCollectionLabel.Name = "toolStripCollectionLabel";
            this.toolStripCollectionLabel.Size = new System.Drawing.Size(56, 17);
            this.toolStripCollectionLabel.Text = "Collection:";
            // 
            // toolStripCollection
            // 
            this.toolStripCollection.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripCollection.Name = "toolStripCollection";
            this.toolStripCollection.Size = new System.Drawing.Size(78, 17);
            this.toolStripCollection.Text = "Not Connected";
            // 
            // toolStripVersionLabel
            // 
            this.toolStripVersionLabel.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripVersionLabel.Name = "toolStripVersionLabel";
            this.toolStripVersionLabel.Size = new System.Drawing.Size(48, 17);
            this.toolStripVersionLabel.Text = "Version:";
            // 
            // toolStripVersion
            // 
            this.toolStripVersion.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripVersion.Name = "toolStripVersion";
            this.toolStripVersion.Size = new System.Drawing.Size(78, 17);
            this.toolStripVersion.Text = "Not Connected";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 642);
            this.ContextMenuStrip = this.contextMenuMain;
            this.Controls.Add(this.statusStripMain);
            this.Controls.Add(this.rtfMain);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Text = "TFS Projects";
            this.Load += new System.EventHandler(this.MainFormLoad);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.contextMenuMain.ResumeLayout(false);
            this.statusStripMain.ResumeLayout(false);
            this.statusStripMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
		private System.Windows.Forms.Button btnConnect;
		private System.Windows.Forms.RichTextBox rtfMain;
        private System.Windows.Forms.ComboBox cboRoles;
		private System.Windows.Forms.Label lblRoles;
		private System.Windows.Forms.Label required1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblHost;
		private System.Windows.Forms.TextBox txtPort;
		private System.Windows.Forms.TextBox txtHost;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Label lblProject;
		private System.Windows.Forms.Label lblPort;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label required4;
        private System.Windows.Forms.Label lblCollection;
        private System.Windows.Forms.TextBox txtCollection;
        private System.Windows.Forms.CheckBox chkTFS2010;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.CheckBox chkEmail;
        private System.Windows.Forms.ContextMenuStrip contextMenuMain;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStripMain;
        private System.Windows.Forms.ToolStripStatusLabel toolStripServerLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripServer;
        private System.Windows.Forms.ToolStripStatusLabel toolStripPortLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripPort;
        private System.Windows.Forms.ToolStripStatusLabel toolStripCollectionLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripCollection;
        private System.Windows.Forms.ToolStripStatusLabel toolStripVersionLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripVersion;
        protected internal System.Windows.Forms.ComboBox cboProject;
		
		
	}
}
