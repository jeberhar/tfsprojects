﻿/*
 ###############################################################################
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################
*/

/*
 * User: jeberhar
 * Copyright 2010 Jay Eberhard
 * 
 */
 
using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Windows.Forms;
using System.Text;
//using System.Threading;

using Microsoft.TeamFoundation.Build.Client;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.Server;
using Microsoft.TeamFoundation.Framework.Client;
using Microsoft.TeamFoundation.Framework.Common;

namespace TFSProjectsWin
{
	/// <summary>
	/// The Main Form for TFS Project Audit
	/// </summary>
	public partial class frmMain : Form
	{
        bool allCollections = false;
        string http = "http://";
        string tfsDir = "/tfs/";
        string colon = ":";
        string serverName = "";
        string portNumber = "";
        string serverURI = "";
        string serverURInospace = ""; //used to display the URI as one continuous string, for display purposes only
        string tfsCollection = "";
        string tfsVersionReadable = "";
        string tfsVersionShort = "";

        ArrayList myCollections = new ArrayList();
        TfsConfigurationServer tfs2010Server;
        TfsTeamProjectCollection tfsConnect;
        ICommonStructureService iss;
        IGroupSecurityService2 gss;
        ProjectInfo[] allTeamProjects;
        Identity[] allProjectGroups;
        ReadOnlyCollection<CatalogNode> tpcNodes;

        public frmMain()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//		

			InitializeComponent();
		}
		
		void BtnConnectClick(object sender, System.EventArgs e)
		{	
            //set the cursor to the hourglass and clear rtfMain in preparation for output
			Cursor.Current = Cursors.WaitCursor;

            //clear out projects and roles combo boxes
            cboRoles.DataSource = null;
            cboProject.DataSource = null;

            //disable project controls in the UI until a connection is made
            disableProjectUIControls();

			rtfMain.Clear();

            //connection level variables
            ArrayList myTeamProjects = new ArrayList();
            ArrayList myTeamRoles = new ArrayList();
            string teamProjectURI = "";
            string allHolder = " All";
            
            //set form level variables from appropriate UI elements
            serverName = txtHost.Text;
            portNumber = txtPort.Text;
            tfsCollection = txtCollection.Text;
            
            //handle collection name in the URI, only available in TFS 2010
            if (chkTFS2010.Checked == true)
            {
                if (tfsCollection.ToLower() == "all-collections")
                {
                    serverURI = string.Concat(http, serverName, colon, portNumber,tfsDir);
                    allCollections = true;
                }
                else
                {
                    serverURI = string.Concat(http, serverName, colon, portNumber, tfsDir, tfsCollection);
                }
            }
            else
            {
                serverURI = string.Concat(http, serverName, colon, portNumber);
            }

            //hide spaces in the server URI by replacing them with underscores. For display purposes only!
            serverURInospace = serverURI;
            if (serverURI.Contains(" "))
            {
                serverURInospace = serverURI.Replace(" ", "_");
            }

            try
			{
				//revert to help text if server name has no value
				if (serverName == "")
				{
					throw new Exception();
				}
				
				//revert to help text if server port has no value
				if (portNumber == "")
				{
					throw new Exception();
				}

                //chkTFS2010 shouldn't be checked if tfsCollection has a value
                if ((chkTFS2010.Checked == true) && (tfsCollection == ""))
                {
                    throw new Exception();
                }

                //chkTFS2010 should be checked if tfsCollection has a value
                if ((chkTFS2010.Checked == false) && (tfsCollection != ""))
                {
                    throw new Exception();
                }

                // Connect to the server

                //forward compatibility pack no longer needed!!!
                Uri tfsUriNew = new Uri(serverURI);
                tfsConnect = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(tfsUriNew);

                if (chkTFS2010.Checked == true)
                {
                    try
                    {
                        string serverURInocollection = string.Concat(http, serverName, colon, portNumber, tfsDir);
                        Uri tfs2010Urinocollection = new Uri(serverURInocollection);
                        tfs2010Server = TfsConfigurationServerFactory.GetConfigurationServer(tfs2010Urinocollection); //for TFS 2010 only
                        CatalogNode tfsCatalog = tfs2010Server.CatalogNode;

                        // Query the children of the configuration server node for all of the team project collection nodes
                        tpcNodes = tfsCatalog.QueryChildren(new Guid[] { CatalogResourceTypes.ProjectCollection }, false, CatalogQueryOptions.None);
                    }
                    catch
                    {
                        string error = "Cannot connect to specified server, check that it is actually running TFS version 2010!\n";
                        processException(error);
                    }
                }

                //get TFS version from the server and apply meaningful name values
                //this breaks 2005 compatibility but new features trump backwards compatibility in my book
                
                IBuildServer buildServer = (IBuildServer)tfsConnect.GetService(typeof(IBuildServer));
                tfsVersionShort = buildServer.BuildServerVersion.ToString();
                
                //put the TFS version into more meaningful verbage
                if (tfsVersionShort == "V3")
                {
                    tfsVersionReadable = "Microsoft Team Foundation Server 2010";
                }
                if (tfsVersionShort == "V2")
                {
                    tfsVersionReadable = "Microsoft Team Foundation Server 2008";
                }

                //add special entry for all project and all roles in the ArrayList which will later populate the ComboBoxes
                myTeamProjects.Add(" All");
                myTeamRoles.Add(" All");

                //if (allCollections == false)
                //{
                //foreach (CatalogNode tpcNode in tpcNodes)
                //{
                    //get ICommonStructureService (later to be used to list all team projects)
                    iss = (ICommonStructureService)tfsConnect.GetService(typeof(ICommonStructureService));

                    // TFS 2010 - get all project collections on the server, used for informational purposes at this point
                    //UNUSED old project collection data gathering
                    //RegisteredProjectCollection[] collections = RegisteredTfsConnections.GetProjectCollections();

                    //get IGroupSecurityService (later to be used to retrieve identity information)
                    gss = (IGroupSecurityService2)tfsConnect.GetService(typeof(IGroupSecurityService2));

                    //list all the TFS Team Projects that exist on a server
                    allTeamProjects = iss.ListProjects();

                    //iterate through each project to populate the ArrayLists for projects and roles, avoiding duplicate roles
                    foreach (ProjectInfo TFSProjectInfo in allTeamProjects)
                    {
                        teamProjectURI = TFSProjectInfo.Uri;

                        //for each Team project identify each security Group
                        allProjectGroups = gss.ListApplicationGroups(teamProjectURI);

                        //filter out duplicate project roles
                        foreach (Identity projectGroup in allProjectGroups)
                        {
                            if (myTeamRoles.Contains(projectGroup.DisplayName.ToString()))
                            {
                                continue;
                            }
                            else
                            {
                                myTeamRoles.Add(projectGroup.DisplayName.ToString());
                            }
                        }
                        myTeamProjects.Add(TFSProjectInfo.Name.ToString()); //no filtering on projects, assumed there are no duplicate projects
                    }
                //}
                //}

                //sort the projects and roles arrays - easier to read if they're alphabetical                
                myTeamProjects.Sort();               
                myTeamRoles.Sort();

                //populate the combo boxes with the values from the ArrayLists
                if (allCollections == false)
                {
                    cboProject.DataSource = myTeamProjects;
                }
                else
                {
                    cboProject.Text = allHolder;
                    cboProject.Items.Add(allHolder);
                }
                cboRoles.DataSource = myTeamRoles;

                //display connection success notification - only reached if no exception was thrown
                rtfMain.AppendText(string.Format("\nConnection successful to {0} please select the roles and project then click OK.\n\n", serverURInospace));

                //display TFS collection information if we connected to a TFS 2010 box
                if (chkTFS2010.Checked == true)
                {
                    rtfMain.AppendText(string.Format("\nThe following collections were reported by {0}:\n", serverName));
                    
                    #region UNUSED old project collection data gathering region
                    /* 
                    foreach (RegisteredProjectCollection TFSCollection in collections)
                    {
                        collectionName = TFSCollection.Name.ToString();
                        //If the backslash isn't in the collection name it is likely not an actually collection, or a badly formed one
                        if (collectionName.Contains(collectionDelimiter) == true)
                        {
                            rtfMain.AppendText(string.Format("\n Collection: {0}", collectionName));
                        }
                    }
                    */
                    #endregion
                    
                    //better 2010 collection data methods
                    foreach (CatalogNode tpcNode in tpcNodes)
                    {
                        // Use tpcNode.Resource to get the details for each team project collection.
                        string defaultCollection = tpcNode.IsDefault.ToString();
                        string displayName = tpcNode.Resource.DisplayName.ToString();
                        string description = tpcNode.Resource.Description.ToString();
                        
                        if (description == "")
                        {
                            description = "Warning: No description specified at collection creation.";
                        }

                        if (allCollections == true)
                        {
                                myCollections.Add(displayName);
                        }

                        rtfMain.AppendText(string.Format("\n Collection Name: {0}\t\tIs Default Collection: {1}\t\tDescription: {2}", displayName, defaultCollection, description));
                    }
                }

                //add the collection name to myCollections regardless of 2008 or 2010
                if (allCollections == false)
                {
                    myCollections.Add(tfsCollection);
                }

                //display the TFS version information
                rtfMain.AppendText(string.Format("\n\nTFS Version Confirmation: {0} on {1}.\n\n", tfsVersionReadable, serverName));

                //enable the project level UI controls
                enableProjectUIControls();

                //set persistent connection info in the toolStrip
                toolStripServer.Text = serverName;
                toolStripPort.Text = portNumber;
                if (tfsVersionShort == "V3")
                {
                    if (allCollections == true)
                    {
                        toolStripCollection.Text = tfsCollection.ToLower();
                    }
                    else
                    {
                        toolStripCollection.Text = tfsCollection;
                    }
                    toolStripVersion.Text = "Team Foundation Server 2010";
                }
                if (tfsVersionShort == "V2")
                {
                    toolStripCollection.Text = "Not Applicable";
                    toolStripVersion.Text = "Team Foundation Server 2008";
                }

                //restore default cursor
				Cursor.Current = Cursors.Default;
			}
			catch (Exception ex)
			{		
                //remove persistent connection info
                toolStripServer.Text = "Not Connected";
                toolStripPort.Text = "Not Connected";
                toolStripCollection.Text = "Not Connected";
                toolStripVersion.Text = "Not Connected";

				//ensure that project level UI controls are disabled
                disableProjectUIControls();

                //neither serverName nor portNumber can be null
                if ((serverName == "") || (portNumber == ""))
                {
                    string error = "Server Name and Port Number can't be null!\n";
                    processException(error);
                    rtfMain.AppendText("\nPlease check your server name and/or port number values and try again.\n");
                }
                //if chkTFS2010 is checked, tfsCollection cannot be null
                else if ((chkTFS2010.Checked == true) && (tfsCollection == ""))
                {
                    string error = "For TFS 2010 a collection name MUST be specified!\n";
                    processException(error);
                    rtfMain.AppendText("\nPlease check your collection name and version input values and try again.\n");
                }
                //if a collection name is specified chkTFS2010 must be checked
                else if ((chkTFS2010.Checked == false) && (tfsCollection.Length > 0))
                {
                    string error = "TFS 2010 collection specified for non-2010 version!\n";
                    processException(error);
                    rtfMain.AppendText("\nPlease check your collection name and/or version input values and try again.\n");
                }
                //catch all other errors - likely connection errors from bad input
                else
                {
                    processException(ex.Message.ToString());
                    rtfMain.AppendText("\nPlease check your input values and try again.\n");
                }
			}
            //reset allCollections, determining its value on each click of Connect
            allCollections = false;
        }

		void BtnOKClick(object sender, EventArgs e)
		{
            //Set the cursor to the hourglass and clear rtfMain in preparation for output
            Cursor.Current = Cursors.WaitCursor;
            btnOK.Enabled = false;
			rtfMain.Clear();
			
            //project level variables
            string projectName = cboProject.Text.ToString();//string variable for the value in the Project combo box
            string providedGroup = cboRoles.Text.ToString(); //string variable for the value in the Project Roles combo box
            string teamProjectName = "";
            string teamProjectUri = "";
            string projGroup = "";
            string collectionNamenospace = ""; //used to display the collection name as one continuous string, for display purposes only
            int projectCount = 0;
            int idCount = 0;
            int totalNumberProjectUsers = 0;
            int numberCollections = 0;
            int totalNumberUsersAllCollections = 0;
            int totalNumberProjects = 0;
            ProjectState teamProjectState;
            Identity projectGroupIdentity;
            Identity tfsID;
            ArrayList myUsers = new ArrayList();
            ArrayList myUsersAllCollections = new ArrayList();

            //clear myCollections so data doesn't keep getting appended
            myCollections.Clear();

            //set allCollections if necessary, which permits reuse of the OK button without reconnecting
            if (toolStripCollection.Text.ToLower() == "all-collections")
            {
                allCollections = true;
            }

            //essentially, reconnect if running tfs2010.  i do it here so the user doesn't have to reconnect every time they change a setting.
            if (tfsVersionShort == "V3")
            {
                try
                {
                    string serverURInocollection = string.Concat(http, serverName, colon, portNumber, tfsDir);
                    Uri tfs2010Urinocollection = new Uri(serverURInocollection);
                    tfs2010Server = TfsConfigurationServerFactory.GetConfigurationServer(tfs2010Urinocollection); //for TFS 2010 only
                    CatalogNode tfsCatalog = tfs2010Server.CatalogNode;
                    
                    //query the children of the configuration server node for all of the team project collection nodes
                    tpcNodes = tfsCatalog.QueryChildren(new Guid[] { CatalogResourceTypes.ProjectCollection }, false, CatalogQueryOptions.None);

                    if (allCollections == true)
                    {
                        foreach (CatalogNode tpcNode in tpcNodes)
                        {
                            myCollections.Add(tpcNode.Resource.DisplayName.ToString());
                        }
                    }
                    else
                    {
                        myCollections.Add(tfsCollection);
                    }
                }
                catch
                {
                    string error = "Cannot connect to specified server, check that it is actually operational and running TFS!\n";
                    processException(error);
                }
            }

            //also ensure that tfs2008 will not need to reconnect.  again, i do this so the user doesn't have to reconnect.
            if (tfsVersionShort == "V2")
            {
                myCollections.Add(tfsCollection);
            }

			try
			{
                //print the output for each collection in myCollections, which will always be at least one, even
                //for 2008 users - even though 2008 doesn't use collections.  tfs2008 is treated as one inclusive collection
                //so users can connect to 2008 and 2010 servers with minimal configuration.
                foreach (string collectionName in myCollections)
                {
                    //increment the number of collections
                    numberCollections = numberCollections + 1;

                    //hide spaces in collectionName by replacing them with underscores. For display purposes only!
                    collectionNamenospace = collectionName;
                    if (collectionName.Contains(" "))
                    {
                        collectionNamenospace = collectionName.Replace(" ", "_");
                    }
                    
                    if (allCollections == true)
                    {
                        //connect to each collection only if allCollections is true, otherwise re-connection is skipped
                        serverURI = string.Concat(http, serverName, colon, portNumber, tfsDir, collectionName);
                        Uri tfsUriNew = new Uri(serverURI);
                        tfsConnect = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(tfsUriNew);
                        iss = (ICommonStructureService)tfsConnect.GetService(typeof(ICommonStructureService));
                        gss = (IGroupSecurityService2)tfsConnect.GetService(typeof(IGroupSecurityService2));
                        allTeamProjects = iss.ListProjects();
                    }

                    //iterate thru the team project list
                    if (projectName == " All")
                    {
                        foreach (ProjectInfo TFSProjectInfo in allTeamProjects)
                        {
                            //ProjectInfo gives you the team project's name, status, and URI.
                            teamProjectName = TFSProjectInfo.Name;
                            teamProjectState = TFSProjectInfo.Status;
                            teamProjectUri = TFSProjectInfo.Uri;

                            //for each Team project identify each security Group
                            allProjectGroups = gss.ListApplicationGroups(teamProjectUri);

                            //skip this team project if it has the specific All selection, which isn't an actual project only a value from the combo box
                            if (teamProjectName == " All")
                            {
                                continue;
                            }

                            //increment projectCount
                            projectCount = projectCount + 1;

                            //increment the total number of projects for all collections
                            totalNumberProjects = totalNumberProjects + 1;

                            //print team project info
                            if (chkEmail.Checked == false)
                            {
                                //handle 2008 which has no collectionName or print it for 2010
                                if (tfsVersionShort == "V3")
                                {
                                    rtfMain.AppendText(string.Format("\nCollection: {0}\tProject Name: {1}", collectionName, teamProjectName));
                                }
                                if (tfsVersionShort == "V2")
                                {
                                    rtfMain.AppendText(string.Format("\nProject Name: {0}", teamProjectName));
                                }
                            }

                            //skip this team project if it is not WellFormed.
                            if (teamProjectState != ProjectState.WellFormed)
                            {
                                continue;
                            }

                            //iterate thru the project group list and get a list of direct members for each project group
                            foreach (Identity projectGroup in allProjectGroups)
                            {
                                projGroup = projectGroup.DisplayName.ToString();
                                if ((projGroup.Contains(providedGroup) == true) || providedGroup.Equals(" All"))
                                {
                                    //for each Security Group, identify all the users that belong to that group
                                    projectGroupIdentity = gss.ReadIdentity(SearchFactor.Sid, projectGroup.Sid, QueryMembership.Direct);

                                    //only print if we're not simply generating a list of associated email addresses
                                    if (chkEmail.Checked == false)
                                    {
                                        rtfMain.AppendText(string.Format("\n\tProject Group Name: {0}", projectGroupIdentity.DisplayName));
                                    }

                                    //print detailed identity info for each group member
                                    foreach (String groupMemberSID in projectGroupIdentity.Members)
                                    {
                                        idCount = idCount + 1;

                                        //fetch the user ID info
                                        tfsID = gss.ReadIdentity(SearchFactor.Sid, groupMemberSID, QueryMembership.None);
                                        
                                        //print the name and email for each ID when we're not just printing email addresses
                                        //NOTE: modify the AppendText line if you want more or less user info printed
                                        if (chkEmail.Checked == false)
                                        {
                                            rtfMain.AppendText(string.Format("\n\t\tName : {0}\t\t\tEmail : {1}", tfsID.DisplayName, tfsID.MailAddress));
                                            //rtfMain.AppendText(string.Format("\t\t{0};", tfsID.MailAddress));
                                        }
                                        else //we're only printing email addresses
                                        {
                                            if (myUsers.Contains(tfsID.MailAddress.ToString()) == false)
                                            {
                                                if (tfsID.MailAddress.ToString() != "")
                                                {
                                                    if (allCollections == false)
                                                    {
                                                        myUsers.Add(tfsID.MailAddress.ToString()); //print the email address if myUsers doesn't already contain it, if the address isn't empty, and if allCollections is false
                                                    }
                                                    else
                                                    {
                                                        if (myUsersAllCollections.Contains(tfsID.MailAddress.ToString()) == false) //AnaServInit
                                                        {
                                                            myUsersAllCollections.Add(tfsID.MailAddress.ToString()); //add the address to myUsersAllCollections for email addresses from all collections
                                                        }
                                                    }
                                                    totalNumberProjectUsers = totalNumberProjectUsers + 1; //after we're done with the project add it to the project counter
                                                }
                                            }
                                        }
                                    }

                                    //only print if we're not simply generating a list of associated email addresses
                                    if (chkEmail.Checked == false)
                                    {
                                        rtfMain.AppendText(string.Format("\n\t\tThere are {0} users in the {1} group for {2}.", idCount, projectGroupIdentity.DisplayName, teamProjectName));
                                    }
                                    //reset idCount with each new project group
                                    idCount = 0;
                                }
                            }
                        }

                        //sort the muUsers array in email address generation - easier to read if they're alphabetical
                        myUsers.Sort();

                        //only print what is in the myUsers array if we actually wanted an email list
                        if (chkEmail.Checked == true)
                        {
                            if (allCollections == false)
                            {
                                foreach (string email in myUsers)
                                {
                                    rtfMain.AppendText(string.Format("{0};\n", email.ToLower()));
                                }
                            }
                        }

                        if ((projectCount == 0) && (chkEmail.Checked == false))
                        {
                            rtfMain.AppendText(String.Format("WARNING: {0} has no projects.", collectionNamenospace));
                        }

                        //print closing string depending on the task, email list or regular project description
                        if (chkEmail.Checked == false)
                        {
                            if (allCollections == false)
                            {
                                rtfMain.AppendText(string.Format("\n\nThere are {0} projects on {1}\n", projectCount, serverURInospace));
                            }
                            else
                            {
                                rtfMain.AppendText(string.Format("\n\nThere are {0} projects on {1}{2}\n", projectCount, serverURInospace, collectionNamenospace));
                            }
                        }
                        else //allCollections and chkEmail.Checked == true is handled later in program execution, outside the main collections execution loop
                        {
                            if (allCollections == false)
                            {
                                rtfMain.AppendText(string.Format("\n\nThere are {0} users on {1}\n", totalNumberProjectUsers, serverURInospace));
                            }
                        }

                        //reset variables used in project to null values
                        myUsers.Clear();
                        teamProjectName = "";
                        teamProjectUri = "";
                        projGroup = "";
                        projectCount = 0;
                        idCount = 0;
                        totalNumberProjectUsers = 0;
                        projectGroupIdentity = null;
                        tfsID = null;

                        //set cursor back to the regular arrow
                        Cursor.Current = Cursors.Default;
                       
                    } //end if (end all projects)
                    else //iterate through the groups and users for only one project
                    {
                        ProjectInfo singleTFSProjectInfo = (iss.GetProjectFromName(projectName));

                        string singleProject = singleTFSProjectInfo.Name;
                        string singleURI = singleTFSProjectInfo.Uri;
                        string singleProjectnospace = "";
                        int singleIdCount = 0;

                        //hide spaces in the project name by replacing them with underscores. For display purposes only!
                        singleProjectnospace = singleProject;
                        if (singleProjectnospace.Contains(" "))
                        {
                            singleProjectnospace = singleProjectnospace.Replace(" ", "_");
                        }

                        //only print certain output if we're not just generating an email list
                        if (chkEmail.Checked == false)
                        {
                            rtfMain.AppendText(string.Format("Project Name : {0}", singleProject));
                        }

                        //get the groups for our singleton project
                        Identity[] projectGroups = gss.ListApplicationGroups(singleURI);

                        foreach (Identity projectGroup in projectGroups)
                        {
                            projGroup = projectGroup.DisplayName.ToString();

                            if ((projGroup.Contains(providedGroup) == true) || providedGroup.Contains(" All"))
                            {
                                // For each Security Group identify all the users that belong to that group
                                projectGroupIdentity = gss.ReadIdentity(SearchFactor.Sid, projectGroup.Sid, QueryMembership.Direct);

                                //only print if we're not simply generating a list of associated email addresses
                                if (chkEmail.Checked == false)
                                {
                                    rtfMain.AppendText(string.Format("\n\tProject Group Name : {0}", projectGroupIdentity.DisplayName));
                                }

                                // Print detailed identity info for each group member
                                foreach (String groupMemberSid in projectGroupIdentity.Members)
                                {
                                    singleIdCount = singleIdCount + 1;
                                    tfsID = gss.ReadIdentity(SearchFactor.Sid, groupMemberSid, QueryMembership.None);
                                    if (chkEmail.Checked == false)
                                    {
                                        rtfMain.AppendText(string.Format("\n\t\tName : {0}\t\t\tEmail : {1}", tfsID.DisplayName, tfsID.MailAddress));
                                    }
                                    else
                                    {
                                        if (myUsers.Contains(tfsID.MailAddress.ToString()) == false)
                                        {
                                            if (tfsID.MailAddress.ToString() != "")
                                            {
                                                myUsers.Add(tfsID.MailAddress.ToString());
                                                totalNumberProjectUsers = totalNumberProjectUsers + 1;
                                            }
                                        }
                                    }
                                }

                                //only print if we're not simply generating a list of associated email addresses
                                if (chkEmail.Checked == false)
                                {
                                    rtfMain.AppendText(string.Format("\n\t\tThere are {0} users in the {1} group for {2}.", singleIdCount, projectGroupIdentity.DisplayName, singleProject));
                                }
                                //reset singleIdCount with each new group
                                singleIdCount = 0;
                            }
                        }

                        //sort the muUsers array in email address generation - easier to read if they're alphabetical
                        myUsers.Sort();

                        //only print what is in the myUsers array if we actually wanted an email list
                        if (chkEmail.Checked == true)
                        {
                            foreach (string email in myUsers)
                            {
                                rtfMain.AppendText(string.Format("{0};\n", email.ToLower()));
                            }
                        }


                        //print closing string for email address list generation
                        if (chkEmail.Checked == true)
                        {
                            rtfMain.AppendText(string.Format("\n\nThere are {0} users on {1}/{2}", totalNumberProjectUsers, serverURInospace, singleProjectnospace));
                        }

                        //reset variables used in singleton project to null values
                        myUsers.Clear();
                        singleProject = "";
                        singleURI = "";
                        projGroup = "";
                        singleIdCount = 0;
                        totalNumberProjectUsers = 0;
                        projectGroupIdentity = null;
                        tfsID = null;

                        //restore default cursor
                        Cursor.Current = Cursors.Default;
                    } //end else (end single project)
                }

                //sort the myUsersAllCollections array in email address generation - easier to read if they're alphabetical
                myUsersAllCollections.Sort();

                //only print what is in the myUsersAllCollections array if we actually wanted an email list
                if (chkEmail.Checked == true)
                {
                    if (allCollections == true)
                    {
                        foreach (string email in myUsersAllCollections)
                        {
                            rtfMain.AppendText(string.Format("{0};\n", email.ToLower()));
                            totalNumberUsersAllCollections = totalNumberUsersAllCollections + 1;
                        }
                    }
                }

                //print summary data for all collections if allCollections is true 
                if (allCollections == true)
                {
                    if (chkEmail.Checked == true)
                    {
                        rtfMain.AppendText(string.Format("\nThere are {0} total collections, {1} total projects and {2} total users on {3}", numberCollections, totalNumberProjects, totalNumberUsersAllCollections, serverURInospace));
                    }
                    else
                    {
                        rtfMain.AppendText(string.Format("\nThere are {0} total collections and {1} total projects on {2}", numberCollections, totalNumberProjects, serverURInospace));
                    }
                }

                //clear out the collections array
                myCollections.Clear();

                //set allCollections to false 
                allCollections = false;

                //zero out the counters
                numberCollections = 0;
                totalNumberProjects = 0;

			} //end try

            //catch all errors, display exception message and direct user to try again
			catch (Exception ex)
			{
                processException(ex.Message.ToString());
                rtfMain.AppendText("\nPlease check the status of your TFS instance and try again.\n");
			}
            btnOK.Enabled = true;
		}
				
		void MainFormLoad(object sender, EventArgs e)
		{
            //ensure that project level UI controls are disabled
            disableProjectUIControls();

			rtfMain.AppendText("\nTFS Project Audit 1.7 by Jay Eberhard Copyright 2010.\n\n");
			rtfMain.AppendText("Press the Help button at any time for information for the description and usage info.\n\n");
			rtfMain.AppendText("Protected by GPL, read COPYING.txt before making any changes.\n\n");
            rtfMain.AppendText("UPDATE: The TFS 2010 Forward Compatibility Pack is no longer required in version 1.7 of TFS Projects!\n\n");
            rtfMain.AppendText("TFS 2005 Users MUST use version 1.0 of TFS Projects, which is available on http://tfsprojects.codeplex.com");
            rtfMain.AppendText("\nFor email list generation, TFS 2005 users must use TFS Users, which is available at http://tfsusers.codeplex.com");
		}

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.DefaultExt = "*.rtf";
            sfd.Filter = "RTF Files|*.rtf";

            if ((sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK) && sfd.FileName.Length > 0)
            {
                rtfMain.SaveFile(sfd.FileName);
            }
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            rtfMain.Clear();
            helpText();
        }

        #region local methods
        void helpText()
        {
            //new in 1.7 - new TFS connection mechanism using 2010 API - no forward compat pack needed!!!, persistent connection information display via toolStrip, ability to work with all collections via "all-collections", better collection data reporting, user email list generation, code cleanup and 50% reduction in download size, context menus, UI readability enhancements
            rtfMain.AppendText("TFS Projects -- Team Foundation Server Project Audit Tool\n\n");
            rtfMain.AppendText("FUNCTION: lists all users for each project for all collections or a specified collection or for only one project within a collection and their roles for a TFS installation.");
            rtfMain.AppendText("Individual projects may be selected from the provided combo box once the connection is established.");
            rtfMain.AppendText("\n\nUPDATE: The TFS 2010 Forward Compatibility Pack is no longer required in version 1.7 of TFS Projects!\n\n");
            rtfMain.AppendText("USAGE: Supply a valid TFS name, port number and TFS Version and collection name (if applicable), then click Connect.\n\nUpon successful connection, select project role or all roles for all projects or individual project and click OK.  " +
                               "\nOptionally, a specific project or role on the server may be selected.  Results can also be saved by clicking the Save... button. \n\n");
            rtfMain.AppendText("To generate a list of email addresses rather than verbose project information based on the specified criteria, check the Email Address List check box.\n\n");
            rtfMain.AppendText("Project related user interface items will only become available upon successful connection to the TFS instance provided.\n\n");
            rtfMain.AppendText("When specifying a collection for TFS 2010, you only need supply the actual collection name. A server name or any backslashes should not be included in the collection name.\n\n");
            rtfMain.AppendText("To gather data from all collections on a TFS server specify \"all-collections\" without quotes as the collection name in the Collection field.\n\n");
            rtfMain.AppendText("If no collection names are known use all-collections and a list of collections on the server will be provided then you can simply reconnect to the one you need.\n\n");
            rtfMain.AppendText("TFS port is 8080 by default, if this value gives an error contact your TFS admin for your port number.");
            rtfMain.AppendText("\n\nTFS 2005 Users MUST use version 1.0 of TFS Projects, which is available at http://tfsprojects.codeplex.com");
            rtfMain.AppendText("\nFor email list generation, TFS 2005 users must use TFS Users, which is available at http://tfsusers.codeplex.com");
            rtfMain.AppendText("\n\nTFS Project Audit 1.7 by Jay Eberhard Copyright 2010.");

        }

        void processException(string message)
        {
            string error = "\nERROR: " + message + "\n";
            if (message != "") { rtfMain.AppendText(error); }
            rtfMain.SelectionStart = 0;
            rtfMain.SelectionLength = error.Length;
            rtfMain.SelectionColor = Color.Red;
            rtfMain.SelectionLength = 0;
            rtfMain.SelectionColor = Color.Black;
        }

        void disableProjectUIControls()
        {
            //disable project controls in the UI until a connection is made
            cboProject.Text = "";
            cboRoles.Text = "";
            chkEmail.Checked = false;
            lblRoles.Enabled = false;
            cboRoles.Enabled = false;
            lblProject.Enabled = false;
            cboProject.Enabled = false;
            btnSave.Enabled = false;
            btnOK.Enabled = false;
            chkEmail.Enabled = false;
        }

        void enableProjectUIControls()
        {
            //enable the project level UI controls
            lblRoles.Enabled = true;
            cboRoles.Enabled = true;
            lblProject.Enabled = true;
            cboProject.Enabled = true;
            btnSave.Enabled = true;
            btnOK.Enabled = true;
            chkEmail.Enabled = true;
        }
        #endregion

        #region contextual menu actions

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtfMain.Copy();
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtfMain.SelectAll();
        }

        #endregion
    }
}